import { Github, Linkedin, Mail, Heart } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    {
      name: 'GitHub',
      url: 'https://github.com',
      icon: Github,
      gradient: 'from-gray-700 to-gray-900',
    },
    {
      name: 'LinkedIn',
      url: 'https://linkedin.com',
      icon: Linkedin,
      gradient: 'from-blue-600 to-blue-800',
    },
    {
      name: 'Email',
      url: 'mailto:hello@johndoe.com',
      icon: Mail,
      gradient: 'from-red-500 to-pink-600',
    },
  ];

  return (
    <footer className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 via-purple-600/10 to-pink-600/10"></div>

      <div className="container mx-auto px-6 py-12 relative z-10">
        <div className="flex flex-col items-center justify-center space-y-8">
          <div className="flex gap-6">
            {socialLinks.map((social) => (
              <a
                key={social.name}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`group p-4 bg-gradient-to-br ${social.gradient} rounded-xl shadow-lg hover:shadow-2xl transform hover:scale-110 hover:-translate-y-1 transition-all duration-300`}
                aria-label={social.name}
              >
                <social.icon size={24} className="text-white" />
              </a>
            ))}
          </div>

          <div className="text-center">
            <p className="text-gray-300 text-lg mb-2">
              © {currentYear} <span className="font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">John Doe</span>. All rights reserved.
            </p>
            <p className="text-gray-400 flex items-center justify-center gap-2 text-sm">
              Built with <Heart size={16} className="text-red-500 animate-pulse" /> using
              <span className="font-semibold text-blue-400">React</span> &
              <span className="font-semibold text-green-400">FastAPI</span>
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-400">
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="hover:text-blue-400 transition-colors duration-300 font-medium"
            >
              Back to Top ↑
            </button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600"></div>
    </footer>
  );
};

export default Footer;
