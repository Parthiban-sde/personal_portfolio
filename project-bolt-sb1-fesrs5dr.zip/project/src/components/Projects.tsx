import { Github, ExternalLink } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      title: 'Cloud Infrastructure Automation',
      description:
        'Built a complete infrastructure automation platform using Terraform and Ansible. Reduced deployment time by 80% and improved system reliability.',
      techStack: ['Terraform', 'Ansible', 'AWS', 'Python'],
      github: 'https://github.com',
      demo: 'https://demo.com',
      gradient: 'from-blue-500 to-cyan-500',
    },
    {
      title: 'Microservices E-Commerce Platform',
      description:
        'Developed a scalable e-commerce platform using microservices architecture with Docker and Kubernetes. Handles 10k+ requests per minute.',
      techStack: ['Node.js', 'Docker', 'Kubernetes', 'MongoDB'],
      github: 'https://github.com',
      demo: 'https://demo.com',
      gradient: 'from-purple-500 to-pink-500',
    },
    {
      title: 'Real-Time Analytics Dashboard',
      description:
        'Created a real-time analytics dashboard for monitoring system metrics and user behavior. Features live data streaming and custom visualizations.',
      techStack: ['React', 'FastAPI', 'PostgreSQL', 'WebSocket'],
      github: 'https://github.com',
      demo: 'https://demo.com',
      gradient: 'from-orange-500 to-yellow-500',
    },
    {
      title: 'CI/CD Pipeline Automation',
      description:
        'Designed and implemented automated CI/CD pipelines using GitHub Actions and Jenkins. Achieved zero-downtime deployments.',
      techStack: ['Jenkins', 'GitHub Actions', 'Docker', 'AWS'],
      github: 'https://github.com',
      demo: 'https://demo.com',
      gradient: 'from-green-500 to-emerald-500',
    },
    {
      title: 'API Gateway & Service Mesh',
      description:
        'Built a high-performance API gateway with service mesh capabilities. Handles authentication, rate limiting, and load balancing.',
      techStack: ['Go', 'Redis', 'Nginx', 'Kubernetes'],
      github: 'https://github.com',
      demo: 'https://demo.com',
      gradient: 'from-red-500 to-pink-500',
    },
    {
      title: 'DevOps Monitoring Suite',
      description:
        'Comprehensive monitoring solution with custom dashboards, alerting, and log aggregation. Integrated with Slack and PagerDuty.',
      techStack: ['Prometheus', 'Grafana', 'ELK Stack', 'Python'],
      github: 'https://github.com',
      demo: 'https://demo.com',
      gradient: 'from-indigo-500 to-purple-500',
    },
  ];

  return (
    <section id="projects" className="py-24 bg-white relative overflow-hidden">
      <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-blue-200 to-purple-200 rounded-full opacity-20 blur-3xl"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-pink-200 to-orange-200 rounded-full opacity-20 blur-3xl"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-orange-600 to-pink-600 bg-clip-text text-transparent">
            Featured Projects
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-orange-600 to-pink-600 mx-auto rounded-full"></div>
          <p className="mt-4 text-gray-600 max-w-2xl mx-auto">
            Showcasing some of my best work in DevOps, backend development, and cloud infrastructure
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {projects.map((project, idx) => (
            <div
              key={idx}
              className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transform hover:-translate-y-3 transition-all duration-300 overflow-hidden border border-gray-100"
            >
              <div className={`h-2 bg-gradient-to-r ${project.gradient}`}></div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-3 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-blue-600 group-hover:to-purple-600 group-hover:bg-clip-text transition-all">
                  {project.title}
                </h3>

                <p className="text-gray-600 mb-4 leading-relaxed">{project.description}</p>

                <div className="flex flex-wrap gap-2 mb-6">
                  {project.techStack.map((tech, techIdx) => (
                    <span
                      key={techIdx}
                      className={`px-3 py-1 bg-gradient-to-r ${project.gradient} text-white text-xs font-semibold rounded-full shadow-md`}
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="flex gap-4">
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-900 transition-colors shadow-md hover:shadow-lg transform hover:scale-105 duration-300"
                  >
                    <Github size={18} />
                    <span className="text-sm font-semibold">Code</span>
                  </a>

                  <a
                    href={project.demo}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex items-center gap-2 px-4 py-2 bg-gradient-to-r ${project.gradient} text-white rounded-lg hover:shadow-lg transform hover:scale-105 transition-all duration-300`}
                  >
                    <ExternalLink size={18} />
                    <span className="text-sm font-semibold">Demo</span>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
