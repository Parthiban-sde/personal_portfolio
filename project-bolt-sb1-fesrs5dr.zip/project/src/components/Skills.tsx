import { Code, Server, Cloud, Database } from 'lucide-react';

const Skills = () => {
  const skillCategories = [
    {
      title: 'Frontend',
      icon: Code,
      gradient: 'from-blue-600 to-cyan-500',
      bgGradient: 'from-blue-50 to-cyan-50',
      skills: [
        { name: 'React', level: 'Advanced' },
        { name: 'TypeScript', level: 'Advanced' },
        { name: 'Tailwind CSS', level: 'Advanced' },
        { name: 'Vue.js', level: 'Intermediate' },
        { name: 'Next.js', level: 'Intermediate' },
      ],
    },
    {
      title: 'Backend',
      icon: Server,
      gradient: 'from-purple-600 to-pink-500',
      bgGradient: 'from-purple-50 to-pink-50',
      skills: [
        { name: 'Node.js', level: 'Advanced' },
        { name: 'Python', level: 'Advanced' },
        { name: 'FastAPI', level: 'Advanced' },
        { name: 'Express.js', level: 'Advanced' },
        { name: 'Go', level: 'Intermediate' },
      ],
    },
    {
      title: 'DevOps',
      icon: Cloud,
      gradient: 'from-orange-600 to-yellow-500',
      bgGradient: 'from-orange-50 to-yellow-50',
      skills: [
        { name: 'Docker', level: 'Advanced' },
        { name: 'Kubernetes', level: 'Advanced' },
        { name: 'AWS', level: 'Advanced' },
        { name: 'Terraform', level: 'Intermediate' },
        { name: 'Jenkins', level: 'Intermediate' },
        { name: 'GitHub Actions', level: 'Advanced' },
      ],
    },
    {
      title: 'Databases',
      icon: Database,
      gradient: 'from-green-600 to-emerald-500',
      bgGradient: 'from-green-50 to-emerald-50',
      skills: [
        { name: 'PostgreSQL', level: 'Advanced' },
        { name: 'MongoDB', level: 'Advanced' },
        { name: 'Redis', level: 'Intermediate' },
        { name: 'MySQL', level: 'Intermediate' },
      ],
    },
  ];

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Advanced':
        return 'bg-gradient-to-r from-green-500 to-emerald-500 text-white';
      case 'Intermediate':
        return 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white';
      case 'Beginner':
        return 'bg-gradient-to-r from-orange-500 to-yellow-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  return (
    <section id="skills" className="py-24 bg-gradient-to-br from-gray-50 to-blue-50 relative overflow-hidden">
      <div className="absolute top-20 right-20 w-64 h-64 bg-gradient-to-br from-purple-300 to-pink-300 rounded-full opacity-20 blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 left-20 w-64 h-64 bg-gradient-to-br from-blue-300 to-cyan-300 rounded-full opacity-20 blur-3xl animate-pulse delay-1000"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Skills & Expertise
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-purple-600 to-pink-600 mx-auto rounded-full"></div>
          <p className="mt-4 text-gray-600 max-w-2xl mx-auto">
            A comprehensive overview of my technical skills across different domains
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
          {skillCategories.map((category, idx) => (
            <div
              key={idx}
              className={`bg-gradient-to-br ${category.bgGradient} p-6 rounded-2xl shadow-lg hover:shadow-2xl transform hover:-translate-y-3 transition-all duration-300 border border-white/50 group`}
              style={{ animationDelay: `${idx * 100}ms` }}
            >
              <div className="mb-6">
                <div className={`inline-block p-4 bg-gradient-to-br ${category.gradient} rounded-xl shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                  <category.icon className="text-white" size={32} />
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mt-4">{category.title}</h3>
              </div>

              <div className="space-y-3">
                {category.skills.map((skill, skillIdx) => (
                  <div
                    key={skillIdx}
                    className="bg-white p-3 rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-gray-800">{skill.name}</span>
                    </div>
                    <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${getLevelColor(skill.level)}`}>
                      {skill.level}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
