import { GraduationCap, Target, Briefcase } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-24 bg-white relative overflow-hidden">
      <div className="absolute top-0 right-0 w-72 h-72 bg-gradient-to-br from-blue-200 to-cyan-200 rounded-full opacity-20 blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-gradient-to-br from-purple-200 to-pink-200 rounded-full opacity-20 blur-3xl"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            About Me
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto rounded-full"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-8 rounded-2xl shadow-lg hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-300 border border-blue-100">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-xl shadow-lg">
                  <Briefcase className="text-white" size={24} />
                </div>
                <h3 className="text-2xl font-bold text-gray-800">Professional Bio</h3>
              </div>
              <p className="text-gray-600 leading-relaxed">
                I'm a passionate DevOps Engineer and Backend Developer with 5+ years of experience
                in building scalable cloud infrastructure. I specialize in automating deployment
                pipelines, optimizing system performance, and creating robust backend services.
                My journey in tech has been driven by curiosity and a commitment to continuous learning.
              </p>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-8 rounded-2xl shadow-lg hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-300 border border-purple-100">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-gradient-to-br from-purple-600 to-pink-500 rounded-xl shadow-lg">
                  <GraduationCap className="text-white" size={24} />
                </div>
                <h3 className="text-2xl font-bold text-gray-800">Education</h3>
              </div>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-gray-800">Bachelor of Computer Science</h4>
                  <p className="text-gray-600">University of Technology | 2015 - 2019</p>
                  <p className="text-sm text-gray-500">GPA: 3.8/4.0</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800">AWS Certified Solutions Architect</h4>
                  <p className="text-gray-600">Amazon Web Services | 2021</p>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-gradient-to-br from-orange-50 to-yellow-50 p-8 rounded-2xl shadow-lg hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-300 border border-orange-100">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-gradient-to-br from-orange-600 to-yellow-500 rounded-xl shadow-lg">
                  <Target className="text-white" size={24} />
                </div>
                <h3 className="text-2xl font-bold text-gray-800">Career Focus</h3>
              </div>
              <p className="text-gray-600 leading-relaxed mb-4">
                My primary focus is on building reliable, scalable infrastructure that empowers
                development teams to ship faster and with confidence. I'm particularly interested in:
              </p>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start gap-2">
                  <span className="text-orange-600 font-bold">•</span>
                  Cloud-native architecture and microservices
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-orange-600 font-bold">•</span>
                  Infrastructure as Code (Terraform, Ansible)
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-orange-600 font-bold">•</span>
                  Container orchestration with Kubernetes
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-orange-600 font-bold">•</span>
                  CI/CD automation and DevOps best practices
                </li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-8 rounded-2xl shadow-lg hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-300 border border-green-100">
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Goals & Vision</h3>
              <p className="text-gray-600 leading-relaxed">
                I aim to continue pushing the boundaries of DevOps and backend development,
                contributing to open-source projects, and mentoring aspiring developers.
                My goal is to architect systems that not only perform exceptionally but also
                provide seamless developer experiences.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
