import { Download, FileText, Award, Briefcase, Code } from 'lucide-react';

const Resume = () => {
  return (
    <section id="resume" className="py-24 bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 relative overflow-hidden">
      <div className="absolute top-20 right-20 w-80 h-80 bg-gradient-to-br from-blue-300 to-purple-300 rounded-full opacity-20 blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 left-20 w-80 h-80 bg-gradient-to-br from-pink-300 to-orange-300 rounded-full opacity-20 blur-3xl animate-pulse delay-1000"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
            Resume
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-cyan-600 mx-auto rounded-full"></div>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 border border-gray-100">
            <div className="text-center mb-8">
              <div className="inline-block p-6 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl shadow-xl mb-6">
                <FileText className="text-white" size={48} />
              </div>
              <h3 className="text-3xl font-bold text-gray-800 mb-4">
                Professional Resume
              </h3>
              <p className="text-gray-600 text-lg max-w-2xl mx-auto">
                Download my complete professional resume to learn more about my experience,
                skills, and achievements in DevOps and Backend Development.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-6 rounded-xl border border-blue-100 transform hover:scale-105 transition-all duration-300">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-lg">
                    <Briefcase className="text-white" size={20} />
                  </div>
                  <h4 className="font-bold text-gray-800">Experience</h4>
                </div>
                <p className="text-gray-600 text-sm">5+ Years Professional</p>
              </div>

              <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-xl border border-purple-100 transform hover:scale-105 transition-all duration-300">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-gradient-to-br from-purple-600 to-pink-500 rounded-lg">
                    <Award className="text-white" size={20} />
                  </div>
                  <h4 className="font-bold text-gray-800">Certifications</h4>
                </div>
                <p className="text-gray-600 text-sm">AWS & Cloud Certified</p>
              </div>

              <div className="bg-gradient-to-br from-orange-50 to-yellow-50 p-6 rounded-xl border border-orange-100 transform hover:scale-105 transition-all duration-300">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-gradient-to-br from-orange-600 to-yellow-500 rounded-lg">
                    <Code className="text-white" size={20} />
                  </div>
                  <h4 className="font-bold text-gray-800">Projects</h4>
                </div>
                <p className="text-gray-600 text-sm">50+ Completed</p>
              </div>
            </div>

            <div className="text-center">
              <a
                href="/resume.pdf"
                download
                className="group inline-flex items-center gap-3 px-10 py-5 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white rounded-full font-bold text-lg shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 relative overflow-hidden"
              >
                <span className="relative z-10 flex items-center gap-3">
                  <Download size={24} />
                  Download Resume (PDF)
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-pink-600 via-purple-600 to-blue-600 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"></div>
              </a>
              <p className="mt-4 text-sm text-gray-500">
                PDF Format • Updated December 2024
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Resume;
